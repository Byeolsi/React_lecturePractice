// let arr = new Array(); // 생성자 이용
let arr = [1, "2", true, null, undefined, {}, [], function () {}]; // 배열 리터럴
console.log(arr);

// 배열의 요소 추가
arr.push(6);
console.log(arr);

// 배열의 길이
console.log(arr.length);
